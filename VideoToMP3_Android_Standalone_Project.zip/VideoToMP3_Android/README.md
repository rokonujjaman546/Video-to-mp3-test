# VideoToMP3 Android — Standalone Offline Runtime

এই Android app ভিডিও থেকে MP3 extract করে। APK install হওয়ার পর conversion-এর জন্য Internet/API দরকার নেই; FFmpeg engine APK-এর dependency হিসেবে package হয়।

## Build
1. GitHub-এ এই project upload করুন।
2. GitHub Actions-এ Android build চালান অথবা Android Studio-তে খুলুন।
3. Gradle dependency প্রথম build-এ internet থেকে FFmpegKit আনবে।
4. APK install করুন।
5. এরপর airplane mode-এও Video → MP3 conversion চলবে।

## Output
MP3 files app-এর Music/VideoToMP3 app-specific directory-তে রাখা হয়।

## Important
FFmpegKit upstream project retired/archived হওয়ায় ভবিষ্যতে dependency availability বদলাতে পারে। এই project runtime offline design দেখায়, কিন্তু build-time dependency retrieval online হতে পারে।

যদি production release করতে চান, FFmpegKit-এর পরিবর্তে একটি actively maintained FFmpeg Android distribution বা নিজের bundled native FFmpeg build pin করা উচিত।
