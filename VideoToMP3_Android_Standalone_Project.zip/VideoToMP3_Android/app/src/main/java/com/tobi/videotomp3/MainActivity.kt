package com.tobi.videotomp3

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import com.google.android.material.button.MaterialButton
import java.io.File

class MainActivity : AppCompatActivity() {
    private val PICK_VIDEO = 1001
    private var selectedUri: Uri? = null
    private lateinit var fileName: android.widget.TextView
    private lateinit var status: android.widget.TextView
    private lateinit var progress: android.widget.ProgressBar
    private lateinit var convertButton: MaterialButton
    private lateinit var qualitySpinner: android.widget.Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fileName = findViewById(R.id.fileName)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        convertButton = findViewById(R.id.convertButton)
        qualitySpinner = findViewById(R.id.qualitySpinner)

        val qualities = listOf("128 kbps", "192 kbps", "256 kbps", "320 kbps")
        qualitySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, qualities)

        findViewById<MaterialButton>(R.id.selectButton).setOnClickListener { pickVideo() }
        convertButton.setOnClickListener { convertToMp3() }
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "video/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, PICK_VIDEO)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            selectedUri?.let {
                try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                fileName.text = "🎬 ${it.lastPathSegment ?: "Selected video"}"
                convertButton.isEnabled = true
                status.text = "ভিডিও প্রস্তুত"
            }
        }
    }

    private fun convertToMp3() {
        val uri = selectedUri ?: return
        convertButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "ভিডিও পড়া হচ্ছে..."

        val input = File(cacheDir, "input_${System.currentTimeMillis()}.mp4")
        contentResolver.openInputStream(uri)?.use { inputStream ->
            input.outputStream().use { output -> inputStream.copyTo(output) }
        } ?: run {
            fail("ভিডিও পড়া যায়নি")
            return
        }

        val musicDir = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "VideoToMP3")
        if (!musicDir.exists()) musicDir.mkdirs()
        val base = (fileName.text.toString().substringAfter("🎬 ").substringBeforeLast("."))
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
        val output = File(musicDir, "${base}_${System.currentTimeMillis()}.mp3")
        val bitrate = when (qualitySpinner.selectedItemPosition) {
            0 -> "128k"; 1 -> "192k"; 2 -> "256k"; else -> "320k"
        }

        val cmd = "-y -i "${input.absolutePath}" -vn -c:a libmp3lame -b:a $bitrate -ar 44100 "${output.absolutePath}""
        FFmpegKit.executeAsync(cmd,
            { session ->
                input.delete()
                val rc = session.returnCode
                runOnUiThread {
                    if (ReturnCode.isSuccess(rc)) {
                        progress.progress = 100
                        status.text = "✅ MP3 তৈরি হয়েছে"
                        Toast.makeText(this, "Saved: ${output.name}", Toast.LENGTH_LONG).show()
                    } else {
                        fail("Conversion ব্যর্থ হয়েছে")
                    }
                }
            },
            { log -> },
            { stats: Statistics ->
                val time = stats.time
                // Duration may be unknown; show an activity indicator instead of fake percent.
                runOnUiThread { status.text = "Conversion চলছে... ${time / 1000}s" }
            }
        )
    }

    private fun fail(message: String) {
        convertButton.isEnabled = true
        progress.visibility = View.GONE
        status.text = "❌ $message"
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
