plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tobi.videotomp3"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tobi.videotomp3"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Runtime conversion is fully local after the APK is installed.
    // Build downloads this dependency once from Maven Central.
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2")
}
